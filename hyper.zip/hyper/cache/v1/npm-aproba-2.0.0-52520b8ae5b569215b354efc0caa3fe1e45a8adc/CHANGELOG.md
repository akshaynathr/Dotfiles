2.0.0
  * Drop support for 0.10 and 0.12. They haven't been in travis but still,
    since we _know_ we'll break with them now it's only polite to do a
    major bump.
